import SwiftUI

struct ArcProgressViewStyle: ProgressViewStyle {
    var color = Color.blue
    var style = StrokeStyle(lineWidth: CGFloat(12), lineCap: .round)
    
    func makeBody(configuration: ProgressViewStyleConfiguration) -> some View {
        let frac = CGFloat(configuration.fractionCompleted ?? 0)
        return Circle()
            .trim(from: 0, to: frac)
            .stroke(color, style: style)
            .rotationEffect(.degrees(-90))
    }
}

struct ContentView: View {
    @State private var values = [0,50,100,150,200,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,1000]
    @AppStorage("totalSelectedWater") var totalSelectedWater = Int()
    @State var newSelectedWater: Int = 0
    @State var userTotal: Double = 2000
    var body: some View {
        VStack {
            Text("Water progress")
                .font(.title)
                .padding(.all)
            ZStack {
                // Draw the progress view around circle
                ProgressView(value:(Double(totalSelectedWater)), total: userTotal)
                    .progressViewStyle(ArcProgressViewStyle())
                // Select water to add
                ZStack {
                    Circle()
                        .scaleEffect(x: -0.8, y: -0.8 ,anchor: .center)
                        .accentColor(.primary)
                    Picker(selection: $newSelectedWater, label: Text("select water picker")) {
                        ForEach(values, id:\.self) {
                            Text("\($0) ml")
                        }
                    }
                }
            }
            .frame(width: 100, height: 100)
            Spacer()
            // Draw cup, add progress in %
            ZStack {
                // water filling up the glass
                Rectangle()
                    .frame(width: 73, height: 75)
                    .scaleEffect(x: 1, y: Double((Double(totalSelectedWater) * 0.0125)/25), anchor: .bottom)
                    .foregroundColor(.blue)
                    .cornerRadius(25)
                    
                Image(systemName: "rectangle.roundedbottom")
                    .resizable()
                    .symbolRenderingMode(.multicolor)
                    .frame(width: 75, height:75)
                    .onTapGesture(count: 2) {
                        totalSelectedWater = 0
                    }
                Text("\(Int(Double(totalSelectedWater*100)/userTotal))%")
            }
            // creater a button to add and show the data
            Button("Add water",action: {
                totalSelectedWater+=newSelectedWater
                newSelectedWater=0
                })
                .accentColor(.primary)
                .padding(.all)
                .background(Color.cyan)
                .cornerRadius(30)
                .padding(.all)
        }
        // the following applies to all within the stack
        .frame(width: 270, height: 370)
    }
}

